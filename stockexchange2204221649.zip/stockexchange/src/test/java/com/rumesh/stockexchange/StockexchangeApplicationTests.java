package com.rumesh.stockexchange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockexchangeApplicationTests {

	@Test
	void contextLoads() {
	}

}
